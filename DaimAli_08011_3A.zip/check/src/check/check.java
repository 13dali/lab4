package check;


import java.nio.file.attribute.BasicFileAttributes;
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.FileVisitResult;
import java.nio.file.SimpleFileVisitor;
import static java.nio.file.FileVisitResult.*;
import java.io.*;


public class check extends SimpleFileVisitor<Path> {

    /**
     * @param args the command line arguments
     */
    
    // Print information about
    // each type of file.
    @Override
    public FileVisitResult visitFile(Path file,
                                   BasicFileAttributes attr) {
        if (attr.isSymbolicLink()) {
            System.out.format("Symbolic link: %s ", file);
        } else if (attr.isRegularFile()) {
            System.out.format("Regular file: %s ", file);
        } else {
            System.out.format("Other: %s ", file);
        }
        System.out.println("(" + attr.size() + "bytes)");
        return CONTINUE;
    }

    // Print each directory visited.
    @Override
    public FileVisitResult postVisitDirectory(Path dir,
                                          IOException exc) {
        System.out.format("Directory: %s%n", dir);
        return CONTINUE;
    }

    // If there is some error accessing
    // the file, let the user know.
    // If you don't override this method
    // and an error occurs, an IOException 
    // is thrown.
    @Override
    public FileVisitResult visitFileFailed(Path file,
                                       IOException exc) {
        System.err.println(exc);
        return CONTINUE;
    }

    /**
     * Directory is valid if it exists, does not represent a file, and can be read.
     */
     public void validateDirectory (
       File aDirectory
     ) throws FileNotFoundException {
       if (aDirectory == null) {
         throw new IllegalArgumentException("Directory should not be null.");
       }
       if (!aDirectory.exists()) {
         throw new FileNotFoundException("Directory does not exist: " + aDirectory);
       }
       if (!aDirectory.isDirectory()) {
         throw new IllegalArgumentException("Is not a directory: " + aDirectory);
       }
       if (!aDirectory.canRead()) {
         throw new IllegalArgumentException("Directory cannot be read: " + aDirectory);
       }
     }
     
    public static final class ProcessFile extends SimpleFileVisitor<Path> {
    	    @Override public FileVisitResult visitFile(
    	      Path aFile, BasicFileAttributes aAttrs
    	    ) throws IOException {
    	      System.out.println("Processing file:" + aFile);
    	      return FileVisitResult.CONTINUE;
    	    }
    	    
    	    @Override  public FileVisitResult preVisitDirectory(
    	      Path aDir, BasicFileAttributes aAttrs
    	    ) throws IOException {
    	      System.out.println("Processing directory:" + aDir);
    	      return FileVisitResult.CONTINUE;
    	    }
    	  }
    
    public class Index {
        public  void index(String text, Path p ) throws IOException {
            Scanner s = null;
            try {
                s = new Scanner(new BufferedReader(new FileReader(text)));

                while (s.hasNext()) {
                    // **split the string and match it for your key here** 
                    System.out.println(s.next());
                }
            } finally {
                if (s != null) {
                    s.close();
                }
            }
        }
    }
     
    public static void main(String[] args) throws IOException {
        check check = new check();
        Scanner console = new Scanner(System.in);
        System.out.print("Directory to crawl? ");
        String directoryName = console.nextLine();
        Path startingDir = Paths.get(directoryName);
        Files.walkFileTree(startingDir, check);
        
        
        
    }
}