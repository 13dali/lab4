package check;

import static org.junit.Assert.*;

import org.junit.Test;

public class checkTest {

	@Test
	public void testVisitFilePathBasicFileAttributes() {
		fail("Not yet implemented");
	}

	@Test
	public void testPostVisitDirectoryPathIOException() {
		fail("Not yet implemented");
	}

	@Test
	public void testVisitFileFailedPathIOException() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateDirectory() {
		fail("Not yet implemented");
	}

}
